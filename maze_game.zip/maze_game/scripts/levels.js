define(["level1", "level2", "level3", "level4", "level5"], function (Level1, Level2, Level3, Level4, Level5) {
    var levels = [
        Level1, Level2, Level3, Level4, Level5
    ];

    return levels;
});